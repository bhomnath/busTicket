<style>
    #top-search-result-full
    {width: 100%; height: 80px; background-color: #428bca; margin: 0 auto 0 auto; border-bottom: 1px solid #ddd;}
    #top-from-to-date-show
    {height: 90px; margin: 0px; padding: 1% 3% 1% 3%; width: 90%;}
</style>
<div id="top-search-result-full">
    <h1 style="text-align: center; margin: 0px; color: #fff; padding: 15px 0px 10px 0px;">Thank You</h1>
</div>
<h1>Thank You For Your Booking.</h1>