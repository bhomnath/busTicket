 <div class="modal-dialog" style="width:80%; margin:106px auto; font-size: 18px;">
            <div class="modal-content">
                <div class="modal-header" style="margin:0 auto 0 auto; background-color:#269abc;">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h2 class="modal-title" style="margin:0 auto 0 auto; text-align: center; color: #fff;">Bus Search Result >> Thank You.</h2>
                </div>
                
                <div class="modal-body" style="width:80%; margin: 0 auto 0 auto;">
                    <div class="alert alert-success">
                        
                                

                                <strong>Congratulations ! </strong><span>You have successfully booked your seats through our booking system. Confirmation email has just been to sent your email, please check your email inbox for more details about your booking. Booking seats from here you have accepted the terms and conditions that apply.</span>

                </div>
 
                  
                                 
                    
                </div>
                
                    

                
            </div>
        </div>
   