<div id="right">
<h4>Add New Bus&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url() . 'index.php/dashboard/busInfo'; ?>">View Buses</a></h4><hr class="topLine" />

    <!-- hotel selection -->
    <div class="sucessmsg"> 
        <?php
        if ($this->session->flashdata('message')) {
            echo $this->session->flashdata('message');
        }
        echo validation_errors();
        if (isset($error)) {
            echo $error;
        }
        ?>

    </div> 
    
    <div style="width: 100%; float: left;">
        <div style="width: 25%; float: left; font-size: 1.1em;">
            <p><label for="from">Bus Number:</label><br/>
                <select><option></option></select>
            </p>
        </div>
        <div style="width: 25%; float: left; font-size: 1.1em;">
            <p><label for="date">Date:</label><br/>
                 <input type="text" class="datepicker" id="checkin" value="" readonly="">
            </p>
        </div>
        <input style="margin-top: 45px;" type="submit" value="View Chhalan" id="searchbbutton" class="send"/>
    </div>  
    <div class="clear"></div>
    
    
    
    
 <?php if(!empty($bookingInfo));{ ?>   
    <table width="90%">
        <tr style="border-bottom: 1px solid #ccc; text-align: left;">
            <th>Passenger Name</th>
            <th>From - To</th>
            <th>Date</th>
            <th>Booked Seats</th>
            <th>Price Per Seat</th>
            <th>Total Price</th>
            <th>Bus Name/Number</th>
            <th>Action</th>
        </tr>
   <?php foreach ($bookingInfo as $booker){
       $id = $booker->Id;
       $name = $booker->Booking_person_name;
       $from = $booker->departing_from;
       $to = $booker->departing_to;
       $date = $booker->depart_date;
       $seats = $booker->seats_numbers;
       $total = "800";
       $busId = $booker->bus_id;
       
       $busInforms = $this->dashboard_model->find_bus($busId);
                    foreach ($busInforms as $data){
                     $busname= $data->bus_name;
                     $number = $data->bus_number;
                     $price = $data->price_per_seat;
                        }
       ?>
   
        <tr style="border-bottom: 1px solid #ccc; text-align: left;">
            <td><?php echo $name; ?></td>
            <td><?php echo $from; ?><br/><?php echo $to; ?></td>
            <td><?php echo $date; ?></td>
            <td><?php echo $seats; ?></td>
            <td><?php echo $price; ?></td>
            <td><?php echo $total; ?></td>
            <td><?php echo $busname ."<br/>". $number; ?></td> 
            <td>
                <?php echo anchor('dashboard/edit/'.$id,'<img src="'.  base_url().'contents/images/edit.png"  alt="Edit" class="edit_book">'); ?>&nbsp;&nbsp;&nbsp;/
                <?php echo anchor('dashboard/delete/'.$id,'<img src="'.  base_url().'contents/images/delete.png" alt="Delete" class="delete_book">'); ?>&nbsp;&nbsp;&nbsp;/
                <?php echo anchor('dashboard/print/'.$id,'<img src="'.  base_url().'contents/images/delete.png" alt="Print" class="print_book">'); ?>
            </td>
            
        </tr>
   <?php } ?>
    </table>     
        
        
 <?php } ?>
</div>
</div>
</body>
</html>